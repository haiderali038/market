let navlinks =document.querySelector(".nav-links")

let burger=document.querySelector(".burger")

burger.addEventListener("click",()=>{
    navlinks.classList.toggle("active");
});